Чтобы загрузить шаблон себе, перейдите в папку, указанную в конфиге nginx вашего сайта и выполните следующие команды

<pre lang="markdown">
mkdir -p assets/v1
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/apple-touch-icon.png
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/favicon-96x96.png
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/favicon.ico
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/favicon.svg
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/index.html
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/site.webmanifest
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/web-app-manifest-192x192.png
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/web-app-manifest-512x512.png
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/assets/v1/script.js -P assets/v1
wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/702cab57ffe6fb66bdd63811969e1fc442bc5b88/YouTube%20endless%20captcha/assets/v1/style.css -P assets/v1
 </pre>

Нужные файлы будут загружены а папки созданы.
