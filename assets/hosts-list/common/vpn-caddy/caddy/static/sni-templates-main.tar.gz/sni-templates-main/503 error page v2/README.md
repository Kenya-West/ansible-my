Чтобы загрузить шаблон себе, перейдите в папку, указанную в конфиге nginx вашего сайта и выполните следующие команды

<pre lang="markdown">
  mkdir -p assets
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/41238842e021352c180a41e889f2d943c7540c81/503%20error%20pages/v2/index.html
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/41238842e021352c180a41e889f2d943c7540c81/503%20error%20pages/v2/assets/style.css -P assets
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/41238842e021352c180a41e889f2d943c7540c81/503%20error%20pages/v2/assets/main.js -P assets
    </pre>

Нужные файлы будут загружены а папки созданы.
