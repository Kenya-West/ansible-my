Чтобы загрузить шаблон себе, перейдите в папку, указанную в конфиге nginx вашего сайта и выполните следующие команды

<pre lang="markdown">
  mkdir -p assets
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/7767efb754a878fff4dd249f7fbf7a9f6762eca2/503%20error%20pages/v1/index.html
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/7767efb754a878fff4dd249f7fbf7a9f6762eca2/503%20error%20pages/v1/assets/main.js -P assets
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/7767efb754a878fff4dd249f7fbf7a9f6762eca2/503%20error%20pages/v1/assets/style.css -P assets 
  </pre>

  Нужные файлы будут загружены а папки созданы.
