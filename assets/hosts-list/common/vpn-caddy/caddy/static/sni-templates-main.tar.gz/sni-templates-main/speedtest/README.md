Чтобы загрузить шаблон себе, перейдите в папку, указанную в конфиге nginx вашего сайта и выполните следующие команды

<pre lang="markdown">
  mkdir -p assets
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/apple-touch-icon.png
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/favicon-96x96.png
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/favicon.ico
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/favicon.svg
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/index.html
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/site.webmanifest
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/web-app-manifest-192x192.png
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/web-app-manifest-512x512.png
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/assets/script.js -P assets
  wget https://raw.githubusercontent.com/SmallPoppa/sni-templates/778c0ec9d1bfaf2ba82f563d9402544c4c5407ff/speedtest/assets/style.css -P assets
  </pre>

  Нужные файлы будут загружены а папки созданы.
